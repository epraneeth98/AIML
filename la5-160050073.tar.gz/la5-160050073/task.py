import numpy as np
from utils import *
import math

def preprocess(X, Y):
	''' TASK 0
	X = input feature matrix [N X D] 
	Y = output values [N X 1]
	Convert data X, Y obtained from read_data() to a usable format by gradient descent function
	Return the processed X, Y that can be directly passed to grad_descent function
	NOTE: X has first column denote index of data point. Ignore that column 
	and add constant 1 instead (for bias part of feature set)
	'''
	(rows,cols) = X.shape

	arr = np.ones((rows, 1))
	# print(X)
	# print("++++++++++++++++++++++")
	for i in range(1,cols):
		if type(X[0][i]) != str:
			a = X[:,i]
			a = (a - np.mean(a)*1.0)/(np.std(a))
			#print(a)
			aa = [[a[k]] for k in range(len(a))]
			b = np.array(aa)
			#print(b.shape,ar.shape)
			arr = np.append(arr,b,axis = 1)
		else:
			z = np.unique(X[:,i])
			#print(z)
			a = one_hot_encode(X[:,i],z)
			#int("________________________-")
			#b)
			arr = np.append(arr,a,axis = 1)


	return arr.astype(float),Y.astype(float)

def grad_ridge(W, X, Y, _lambda):
	'''  TASK 2
	W = weight vector [D X 1]
	X = input feature matrix [N X D]
	Y = output values [N X 1]
	_lambda = scalar parameter lambda
	Return the gradient of ridge objective function (||Y - X W||^2  + lambda*||w||^2 )
	'''
	return (-2*(X - np.matmul(Y,W)) +  2*_lambda * W).astype(float)

def ridge_grad_descent(X, Y, _lambda, max_iter=30000, lr=0.00001, epsilon = 1e-4):
	''' TASK 2
	X 			= input feature matrix [N X D]
	Y 			= output values [N X 1]
	_lambda 	= scalar parameter lambda
	max_iter 	= maximum number of iterations of gradient descent to run in case of no convergence
	lr 			= learning rate
	epsilon 	= gradient norm below which we can say that the algorithm has converged 
	Return the trained weight vector [D X 1] after performing gradient descent using Ridge Loss Function 
	NOTE: You may precompure some values to make computation faster
	'''
	(rows,cols) = X.shape

	print(_lambda)
	xty = np.matmul(np.transpose(X),Y)
	xtx = np.matmul(np.transpose(X),X)
	ans = np.zeros((cols, 1))
	for i in range(max_iter):
		prev = ans.copy()
		ans = ans-lr*(grad_ridge(ans,xty,xtx,_lambda))
		if np.linalg.norm(ans - prev)<epsilon:
			break
	return ans

def k_fold_cross_validation(X, Y, k, lambdas, algo):
	''' TASK 3
	X 			= input feature matrix [N X D]
	Y 			= output values [N X 1]
	k 			= number of splits to perform while doing kfold cross validation
	lambdas 	= list of scalar parameter lambda
	algo 		= one of {coord_grad_descent, ridge_grad_descent}
	Return a list of average SSE values (on validation set) across various datasets obtained from k equal splits in X, Y 
	on each of the lambdas given 
	'''
	(N,D) = X.shape
	x = N/k
	arr = []
	x = int(x)
	for i in range(len(lambdas)):
		l = lambdas[i]
		err = 0
		for j in range(k):
			train = np.append(X[0:x*j],X[x*(j+1):N],axis = 0)
			test = X[x*j:x*(j+1)]
			train_label = np.append(Y[0:x*j],Y[x*(j+1):N],axis = 0)
			test_label = Y[x*j:x*(j+1)]
			xyz = algo(train,train_label,l)
			err = err + sse(test,test_label,xyz)
		err = err/k
		arr.append(err)
		print("sse: ",err)
	return arr


def coord_grad_descent(X, Y, _lambda, max_iter=1000):
	''' TASK 4
	X 			= input feature matrix [N X D]
	Y 			= output values [N X 1]
	_lambda 	= scalar parameter lambda
	max_iter 	= maximum number of iterations of gradient descent to run in case of no convergence
	Return the trained weight vector [D X 1] after performing gradient descent using Ridge Loss Function 
	'''
	pass

if __name__ == "__main__":
	# Do your testing for Kfold Cross Validation in by experimenting with the code below 
	X, Y = read_data("./dataset/train.csv")
	X, Y = preprocess(X, Y)
	trainX, trainY, testX, testY = separate_data(X, Y)
	
	lambdas = [i for i in range(0,30,2)] # Assign a suitable list Task 5 need best SSE on test data so tune lambda accordingly
	scores = k_fold_cross_validation(trainX, trainY, 6, lambdas, ridge_grad_descent)
	plot_kfold(lambdas, scores)